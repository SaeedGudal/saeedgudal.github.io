Saeed Gudal
Saeed_Gudal@student.uml.edu
GUI 1
12/16/24
Homework 5

This is an assignment for the drag and drop Scrabble game.
The user is given seven letter tiles on a tile rack and drags tiles to the 
board to create words. Their score is recorded, taking letter values and bonus
squares into consideration. 

Basic functionality / Currently Working: 
- Letter tiles in the player's tile rack are selected randomly from a data structure.
- Letter tiles can be dragged and dropped, and snap to the board slots.
- Program identifies which letter is being dropped onto the board through the "word" tracker
on the score board, as  well as blank board slots.
- The board includes 2 bonus squares, which are double word multipliers.
- Score is tallied correctly, including consideration of the bonus squares. 
- The game keeps track of remaning tiles. 
- Scoreboard shows score and current word.