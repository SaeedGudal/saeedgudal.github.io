/*
Name: Saeed Gudal
Date: 10/30/24
Class: GUI 1
Email: Saeed_Gudal@student.uml.edu
*/


document.querySelector('.btn-submit').addEventListener('click', function() {
    // Capture input values and parse them as numbers
    const xMin = Number(document.querySelector('input[name="input1"]').value);
    const xMax = Number(document.querySelector('input[name="input2"]').value);
    const yMin = Number(document.querySelector('input[name="input3"]').value);
    const yMax = Number(document.querySelector('input[name="input4"]').value);

    // Error message 
    const errorMessage = document.getElementById('error-message');
    errorMessage.textContent = ''; // Clear previous errors

    // Validate inputs: ensures they are numbers within the range -50 to 50
    if (
        isNaN(xMin) || isNaN(xMax) || isNaN(yMin) || isNaN(yMax) ||
        xMin < -50 || xMax > 50 || yMin < -50 || yMax > 50
    ) {
        errorMessage.textContent = "Error: Please Enter a number in between -50 & 50";
        return;
    }

    // Generate multiplication table with validated ranges
    document.getElementById('multiplication-table').innerHTML = generateTable(xMin, xMax, yMin, yMax);
});

function generateTable(xMin, xMax, yMin, yMax) {
    let tableHtml = '<table class="table"><tr><th>*</th>';

    // Generate header row for x values (xMin to xMax)
    for (let x = xMin; x <= xMax; x++) {
        tableHtml += `<th>${x}</th>`;
    }
    tableHtml += '</tr>';

    // Generate rows for each y value (yMin to yMax)
    for (let y = yMin; y <= yMax; y++) {
        tableHtml += `<tr><th>${y}</th>`; // First cell in row is the y value
        for (let x = xMin; x <= xMax; x++) {
            tableHtml += `<td>${x * y}</td>`; // Multiply x and y for the cell value
        }
        tableHtml += '</tr>';
    }
    tableHtml += '</table>';
    return tableHtml;
}
